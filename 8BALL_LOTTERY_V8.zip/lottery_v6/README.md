# 8BALL_LOTTERY_V8

Premium mobile lottery platform: User App + secure Admin App + PostgreSQL.

## Routes
- User: `/`
- Admin: `/admin`
- Health: `/api/health`

## Environment
`DATABASE_URL` = Supabase PostgreSQL URL ending in `/postgres` (never `/postgres/admin`)
`JWT_SECRET` = long random secret
`ADMIN_PIN` = your private admin PIN

## Database
Run `schema.sql` once in the Supabase SQL editor. It is safe for a fresh database and uses IF NOT EXISTS.

## V8 features
- No 100-ticket limit (1 to 1,000,000)
- 3 prizes / 3 winners
- Pool-ball number selector
- Pending -> Paid confirmation
- Round start/close timestamps
- Round and winner history
- Admin search
- Sales dashboard
- Smart threshold notifications
- Private payment/winner notifications
- Live polling
- Admin JWT 30 minutes + 15-minute inactivity logout
